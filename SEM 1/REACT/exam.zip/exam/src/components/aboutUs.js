import React from "react";
import "./aboutUs.css";
import "bootstrap/dist/css/bootstrap.min.css";
export default function () {
  return (
    <div>
      <div id="header">
        <nav className="navbar navbar-expand-lg justify-content-left">
          <div className="home nav-item">
            <a href="/" className="nav-link">
              Home
            </a>
          </div>
          <div className="aboutUs nav-item ">
            <a href="/aboutus" className="nav-link ">
              <b>About Us</b>
            </a>
          </div>
          <div className="register nav-item">
            <a href="/register" className="nav-link">
              Register
            </a>
          </div>
        </nav>
      </div>
      <div id="body-content">
        <h2 className="title">
          <b>About Us</b>
        </h2>

        <div className="box-account">
          <div class="card" style={{ width: "400px" }}>
            <img
              class="card-img-top"
              src="assets/img/avatar.png"
              alt="Card image"
            />
            <div class="card-body">
              <h4 class="card-title">
                <b>CEO:</b> Nguyen Thi Hanh
              </h4>
              <p class="card-text">Some example text.</p>
            </div>
          </div>
          <div class="card" style={{ width: "400px" }}>
            <img
              class="card-img-top"
              src="assets/img/avatar.png"
              alt="Card image"
            />
            <div class="card-body">
              <h4 class="card-title">
                <b>CTO:</b> Nguyen Thanh Binh
              </h4>
              <p class="card-text">Some example text.</p>
            </div>
          </div>
          <div class="card" style={{ width: "400px" }}>
            <img
              class="card-img-top"
              src="assets/img/avatar.png"
              alt="Card image"
            />
            <div class="card-body">
              <h4 class="card-title">
                <b>CFO:</b> Nguyen Van Hoa
              </h4>
              <p class="card-text">Some example text.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
