import React, { useState } from "react";
import "./register.css";
export default function (props) {
  const [data, setData] = useState([]);
  const [product, setProduct] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [mail, setMail] = useState("");
  const submit = (e) => {
    e.preventDefault();
    fetch("http://localhost:8080/posts", {
      method: "POST",
      body: JSON.stringify({
        product: product,
        name: name,
        phone: phone,
        mail: mail,
      }),
      headers: {
        "Content-type": "application/json",
      },
    })
      .then((res) => res.json)
      .then((result) => {
        alert("Registered product information successfully!");
      });
  };
  return (
    <div>
      <div id="header">
        <nav className="navbar navbar-expand-lg justify-content-left">
          <div className="home nav-item">
            <a href="/" className="nav-link">
              Home
            </a>
          </div>
          <div className="aboutUs nav-item">
            <a href="/aboutus" className="nav-link">
              About Us
            </a>
          </div>
          <div className="register nav-item">
            <a href="/register" className="nav-link">
              <b>Register</b>
            </a>
          </div>
        </nav>
      </div>
      <div id="body-content" className="container">
        <form onSubmit={submit}>
          <table>
            <tr>
              <td>
                <b>Product</b>
              </td>
              <td>
                <input
                  type="text"
                  className="inputProduct"
                  value={product}
                  onChange={(e) => setProduct(e.target.value)}
                  required
                />
              </td>
            </tr>
            <tr>
              <td>
                <b>Name</b>
              </td>
              <td>
                <input
                  type="text"
                  className="inputName"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </td>
            </tr>
            <tr>
              <td>
                <b>Phone Number</b>
              </td>
              <td>
                <input
                  type="text"
                  className="inputPhone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </td>
            </tr>
            <tr>
              <td>
                <b>Email</b>
              </td>
              <td>
                <input
                  type="email"
                  className="inputEmail"
                  value={mail}
                  onChange={(e) => setMail(e.target.value)}
                  required
                />
              </td>
            </tr>
          </table>
          <div className="container button">
            <button type="cancel" className="ButtonReset ButtonOption">
              <a href="/" style={{ textDecoration: "none", color: "black" }}>
                Cancel
              </a>
            </button>
            <button type="submit" className="ButtonSubmit ButtonOption">
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
