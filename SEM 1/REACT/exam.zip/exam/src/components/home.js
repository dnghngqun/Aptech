import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./home.css";
export default function () {
  return (
    <div>
      <div id="header">
        <nav className="navbar navbar-expand-lg">
          <div className="home nav-item">
            <a href="/" className="nav-link">
              <b>Home</b>
            </a>
          </div>
          <div className="aboutUs nav-item">
            <a href="/aboutus" className="nav-link">
              About Us
            </a>
          </div>
          <div className="register nav-item">
            <a href="/register" className="nav-link">
              Register
            </a>
          </div>
        </nav>
      </div>
      <div id="body-content" className="container">
        <div className="picture" style={{ margin: "20px auto" }}>
          <img
            src="assets/img/anh-anya_1.jpeg"
            alt="..."
            style={{ width: "100%", objectFit: "cover", borderRadius: "20px" }}
          />
        </div>
      </div>
      <div id="footer" style={{ margin: "0 auto", width: "80%" }}>
        <b>ABC limited liability company</b>
        <p>
          Specializing in providing information technology solutions in the
          fields of AI, Finance...
        </p>
      </div>
    </div>
  );
}
