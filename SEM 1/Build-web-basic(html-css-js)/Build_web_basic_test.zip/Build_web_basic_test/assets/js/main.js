function confirmAdd(){
    confirm('Are you sure add new product?');
    }