function checkForm(){
    let userName = document.getElementById('user-name');
    let us_pw = document.getElementById('user-pw');
    
    if(userName.value == '')
    {
        document.getElementById('username-error').innerHTML = 'You need to enter your email or user name.'
        return false;
    }

    if(us_pw.value =='')
    {
        document.getElementById('pw-error').innerHTML = 'You need to enter your password.'
        return false;
    }
    return true;
}

