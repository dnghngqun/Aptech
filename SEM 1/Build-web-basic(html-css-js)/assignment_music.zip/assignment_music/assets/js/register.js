function validatePassword(input_pw)
{
    var check = new RegExp("^.{4,}$");
    return check.test(input_pw);
}

function checkYear(year)
{
    if (year % 400 == 0)
    {
        return true;
    }

    if(year % 4 == 0 && year % 100 != 0)
    {
        return true;
    }
    return false;
}

function checkDate(day,month,year)
{
// get current date
    var today = new Date();
    var currentDay = today.getDate();
    var currentMonth = today.getMonth() + 1;
    var currentYear = today.getFullYear();
    var bcheckLeapYear = checkYear(year);

    if(day < 1 || month < 1 || year < 1){
        return false;
    }

    if(day > 31 || month > 12||year > currentYear)
    {
        return false;
    }

    if(year > currentYear && month > currentMonth && day > currentDay){
        return false;
    }

    if(month == 2 && year && day > 29||
        month == 2 && !year && day > 28)
    {
        return false;
    }

    if(month == 1 && day > 31||
        month == 3 && day > 31||
        month == 5 && day > 31||
        month == 7 && day > 31||
        month == 8 && day > 31||
        month == 10 && day > 31||
        month == 12 && day > 31)
        {
            return false;
        }
    if(month == 4 && day > 30||
        month == 6 && day > 30||
        month == 9 && day > 30||
        month == 11 && day > 30)
        {
            return false;
        }
        return true;
}

function checkForm(){
    let cName = document.getElementById('name');
    let cEmail = document.getElementById('email');
    let cPassword = document.getElementById('pw');
    let cPw_again = document.getElementById('pw-again');
    let bcheckPw = validatePassword(cPassword.value);
    let iDay = document.getElementById('day-born');
    let iMonth = document.getElementById('month-born');
    let iYear = document.getElementById('year-born');
    let bcheckDate = checkDate(iDay.value, iMonth.value, iYear.value);
    if(cName.value == '')
    {
        document.getElementById('error-name').innerHTML = 'You need to enter your name.';
        return false;
    }

    if(cEmail.value == '')
    {
        document.getElementById('error-email').innerHTML = 'You need to enter your email.';
        return false;
    }

    if(cPassword.value == '')
    {
        document.getElementById('error-pw').innerHTML = 'You need to enter password.';
        return false;
    }

    if(!bcheckPw)
    {
        document.getElementById('error-pw-length').innerHTML = 'Password must be 4 characters or more.'
        return false;
    }

    if(cPw_again.value == '')
    {
        document.getElementById('error-pw-again').innerHTML = 'You need to enter password again.';
        return false;
    }

    if(cPw_again.value !== cPassword.value)
    {
        document.getElementById('error-pw-match').innerHTML = 'Password again do not match.';
        return false;
    }

    if(!bcheckDate)
    {
        document.getElementById('error-date').innerHTML ='Enter a valid date.'
        return false;
    }
    return true;
}

