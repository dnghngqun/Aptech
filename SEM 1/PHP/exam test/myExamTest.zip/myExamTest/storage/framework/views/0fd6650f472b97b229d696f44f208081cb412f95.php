<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">Edit Product</div>
    <div class="card-body">
        <form method="post" action="<?php echo e(route('product.update', $product->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">Product Type</label>
                <div class="col-sm-10">
                    <input type="text" name="ProductType" class="form-control" value="<?php echo e($product->ProductType); ?>" />
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">Product Code</label>
                <div class="col-sm-10">
                    <input type="text" name="ProductCode" class="form-control" value="<?php echo e($product->ProductCode); ?>" />
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form">ProductName</label>
                <div class="col-sm-10">
                    <input type="text" name="ProductName" class="form-control" value="<?php echo e($product->ProductName); ?>" />
                </div>
            </div>
    </div>
    <div class="row mb-3">
        <label class="col-sm-2 col-label-form">Quantity</label>
        <div class="col-sm-10">
            <input type="number" name="Quantity" class="form-control" value="<?php echo e($product->Quantity); ?>" />
        </div>
    </div>
    <div class="row mb-3">
        <label class="col-sm-2 col-label-form">Note</label>
        <div class="col-sm-10">
            <input type="text" name="Note" class="form-control" value="<?php echo e($product->Note); ?>" />
        </div>
    </div>
    <div class="text-center">
        <input type="hidden" name="hidden_id" value="<?php echo e($product->id); ?>" />
        <input type="submit" class="btn btn-primary" value="Edit" />
    </div>
    </form>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/vscodee/vscode/Aptech/PHP/exam test/myExamTest/resources/views/edit.blade.php ENDPATH**/ ?>