<?php $__env->startSection('content'); ?>
<h1>Product List</h1>

<table class="table table-bordered">
    <thead>
        <tr>
            <th scope="col">ProductType</th>
            <th scope="col">Quantity</th>
            <th scope="col-8">Note</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>

        <?php if(count($data) > 0): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($row->ProductType); ?></td>
            <td>$<?php echo e($row->Quantity); ?></td>
            <td><?php echo e($row->Note); ?></td>
            <td>
                <form method="post" action="<?php echo e(route('product.destroy', $row->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <a href="<?php echo e(route('product.show', $row->id)); ?>" class="btn btn-primary btn-sm">View</a>
                    <a href="<?php echo e(route('product.edit', $row->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <input type="submit" class="btn btn-danger btn-sm" value="Delete" />
                </form>
            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="5" class="text-center">No Data Found</td>
        </tr>
        <?php endif; ?>

    </tbody>
</table>

<a class="btn btn-primary" href="<?php echo e(route('product.create')); ?>" role="button">Create Product</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/vscodee/vscode/Aptech/PHP/exam test/myExamTest/resources/views/index.blade.php ENDPATH**/ ?>