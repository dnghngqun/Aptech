<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php else: ?>
<div class="alert alert-error">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Product Details</b></div>
            <div class="col col-md-6">
                <a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary btn-sm float-end mx-1">View All</a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Product Type</b></label>
            <div class="col-sm-10">
                <?php echo e($product->ProductType); ?>

            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Product Code</b></label>
            <div class="col-sm-10">
                <?php echo e($product->ProductCode); ?>

            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>ProductName</b></label>
            <div class="col-sm-10">
                <?php echo e($product->ProductName); ?>

            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Quantity</b></label>
            <div class="col-sm-10">
                <?php echo e($product->Quantity); ?>

            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Note</b></label>
            <div class="col-sm-10">
                <?php echo e($product->Note); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/vscodee/vscode/Aptech/PHP/exam test/myExamTest/resources/views/show.blade.php ENDPATH**/ ?>