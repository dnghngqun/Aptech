<?php $__env->startSection('content'); ?>
<table id="cart" class="table table-hover table-condensed">
    <thead>
        <tr>
            <th style="width:50%">Product</th>
            <th style="width:10%">Price</th>
            <th style="width:8%">Quantity</th>
            <th style="width:22%" class="text-center">Subtotal</th>
            <th style="width:10%"></th>
        </tr>
    </thead>
    <tbody>

        <?php $total = 0 ?>
        <?php if(session('cart')): ?>
        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total += $details['Price'] * $details['quantity'];
        ?>
        <tr>
            <td data-th="Product">
                <div class="row">

                    <div class="col-sm-3 hidden-xs">

                        <img src="images/<?php echo e($details['photo']); ?>" width="100" height="100" class="img-responsive" />

                    </div>
                    <div class="col-sm-9">

                        <h4 class="nomargin"><?php echo e($details['name']); ?></h4>

                    </div>
                </div>
            </td>
            <td data-th="Price">$<?php echo e($details['Price']); ?></td>
            <form action="<?php echo e(route('mobiles.updateCart', ['id' => $id])); ?>" method="GET" class="container">

                <td data-th="quantity">

                    <input type="number" name="quantity" class="form-control quantity" value="<?php echo e($details['quantity']); ?>" min="0">


                </td>

                <td data-th="Subtotal" class="text-center">$<?php echo e($details['Price'] * $details['quantity']); ?></td>

                <td class="actions m-auto" data-th="Subtotal">

                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-primary mb-1 mt-2">Update</button>
                    <a href="<?php echo e(route('mobiles.removeFromCart', ['id' => $id])); ?>" class="btn btn-danger mt-1">Remove</a>

            </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php else: ?>
        <div class="alert alert-error">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
    </tbody>
    <tfoot>
        <tr>
            <td><a href="<?php echo e(route('mobiles.index')); ?>" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
            <td colspan="2" class="hidden-xs"></td>
            <td class="hidden-xs text-center"><strong>Total $<?php echo e($total); ?></strong></td>
        </tr>
    </tfoot>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/vscodee/vscode/Aptech/PHP/Laravel/prj2/resources/views/cart.blade.php ENDPATH**/ ?>