<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        .heading-text {
            width: 100wh;
            height: 100vh;
            text-align: center;
            line-height: 100vh;
        }
    </style>
</head>

<body class="antialiased">
    <h1 class="heading-text">hello please click to button -> <a href="/login" class="btn btn-primary btn-sm">My web</a> </h1>

</body>

</html><?php /**PATH /Volumes/vscodee/vscode/Aptech/PHP/Laravel/prj2/resources/views/welcome.blade.php ENDPATH**/ ?>