<?php $__env->startSection('content'); ?>
<h1>Mobile List</h1>

<a href="/cart" class="btn btn-primary btn-sm float-end">View Cart</a>



<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Model</th>
            <th scope="col">Maker</th>
            <th scope="col">Image</th>
            <th scope="col">Price</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>

        <?php if(count($data) > 0): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th scope="row"><?php echo e($row->id); ?> </th>
            <td><?php echo e($row->mobile_name); ?></td>
            <td><?php echo e($row->model); ?></td>
            <td><?php echo e($row->maker); ?></td>
            <td><img src="<?php echo e(asset('images/' . $row->mobile_image)); ?>" height="40" width="40"></td>
            <td><?php echo e($row->Price); ?></td>
            <td><a href="<?php echo e(route('mobiles.show', $row->id)); ?>">Detail</a></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="5" class="text-center">No Data Found</td>
        </tr>
        <?php endif; ?>

    </tbody>
</table>

<a class="btn btn-primary" href="<?php echo e(route('mobiles.create')); ?>" role="button">Create Mobile</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/vscodee/vscode/Aptech/PHP/Laravel/prj2/resources/views/index.blade.php ENDPATH**/ ?>