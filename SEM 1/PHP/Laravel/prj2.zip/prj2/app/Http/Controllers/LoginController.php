<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Account;
use App\Models\Mobiles;

class LoginController extends Controller
{
    //
    public function show()
    {
        return view('auth.login');
    }

    public function perform(Request $request)
    {
        $accounts = Account::whereEmail($request->email)
            ->wherePassword($request->password)->first();
        if (!empty($accounts)) {
            // login ok -> go to home page
            $data = Mobiles::all();
            return view('index', compact('data'));
        }
        //login not OK
        return redirect()->to('login')
            ->withErrors('Username or password invalid');
    }
}
