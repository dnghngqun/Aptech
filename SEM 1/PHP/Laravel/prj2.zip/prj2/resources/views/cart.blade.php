@extends('master')
@section('content')
<table id="cart" class="table table-hover table-condensed">
    <thead>
        <tr>
            <th style="width:50%">Product</th>
            <th style="width:10%">Price</th>
            <th style="width:8%">Quantity</th>
            <th style="width:22%" class="text-center">Subtotal</th>
            <th style="width:10%"></th>
        </tr>
    </thead>
    <tbody>

        <?php $total = 0 ?>
        @if(session('cart'))
        @foreach(session('cart') as $id => $details)
        <?php $total += $details['Price'] * $details['quantity'];
        ?>
        <tr>
            <td data-th="Product">
                <div class="row">

                    <div class="col-sm-3 hidden-xs">

                        <img src="images/{{ $details['photo'] }}" width="100" height="100" class="img-responsive" />

                    </div>
                    <div class="col-sm-9">

                        <h4 class="nomargin">{{ $details['name'] }}</h4>

                    </div>
                </div>
            </td>
            <td data-th="Price">${{ $details['Price'] }}</td>
            <form action="{{ route('mobiles.updateCart', ['id' => $id]) }}" method="GET" class="container">

                <td data-th="quantity">

                    <input type="number" name="quantity" class="form-control quantity" value="{{ $details['quantity'] }}" min="0">


                </td>

                <td data-th="Subtotal" class="text-center">${{ $details['Price'] * $details['quantity'] }}</td>

                <td class="actions m-auto" data-th="Subtotal">

                    @csrf

                    <button type="submit" class="btn btn-primary mb-1 mt-2">Update</button>
                    <a href="{{ route('mobiles.removeFromCart', ['id' => $id]) }}" class="btn btn-danger mt-1">Remove</a>

            </form>
            </td>
        </tr>
        @endforeach
        @endif


        @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
        @else
        <div class="alert alert-error">
            {{ session('error') }}
        </div>
        @endif
    </tbody>
    <tfoot>
        <tr>
            <td><a href="{{ route('mobiles.index') }}" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
            <td colspan="2" class="hidden-xs"></td>
            <td class="hidden-xs text-center"><strong>Total ${{ $total }}</strong></td>
        </tr>
    </tfoot>
</table>

@endsection