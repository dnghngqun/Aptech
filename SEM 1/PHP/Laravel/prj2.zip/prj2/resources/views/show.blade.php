@extends('master')

@section('content')

@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@else
<div class="alert alert-error">
    {{ session('error') }}
</div>
@endif
<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col col-md-6"><b>Mobile Details</b></div>
            <div class="col col-md-6">
                <a href="{{ route('mobiles.index') }}" class="btn btn-primary btn-sm float-end mx-1">View All</a>
                <a href="/cart" class="btn btn-primary btn-sm float-end">View Cart</a>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Mobile Name</b></label>
            <div class="col-sm-10">
                {{ $mobiles->mobile_name }}
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-sm-2 col-label-form"><b>Model</b></label>
            <div class="col-sm-10">
                {{ $mobiles->model }}
            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Maker</b></label>
            <div class="col-sm-10">
                {{ $mobiles->maker }}
            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Student Image</b></label>
            <div class="col-sm-10">
                <img src="{{ asset('images/' .  $mobiles->mobile_image) }}" width="200" class="img-thumbnail" />
            </div>
        </div>
        <div class="row mb-4">
            <label class="col-sm-2 col-label-form"><b>Price</b></label>
            <div class="col-sm-10">
                {{ $mobiles->Price }}
            </div>
        </div>
        <a href="{{ asset('add-to-cart/'. $mobiles->id)  }}" class="btn btn-primary btn-xl float-left">Add to cart</a>
    </div>
</div>

@endsection('content')